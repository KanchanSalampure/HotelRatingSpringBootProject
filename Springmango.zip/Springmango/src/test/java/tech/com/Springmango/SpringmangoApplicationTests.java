package tech.com.Springmango;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmangoApplicationTests {

	@Test
	void contextLoads() {
	}

}
